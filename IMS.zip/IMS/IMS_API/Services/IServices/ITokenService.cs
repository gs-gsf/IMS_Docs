﻿using IMS_API.Models;

namespace IMS_API.Services.IServices
{
    public interface ITokenService
    {
        Task<string> GenerateJwtTokenAsync(ApplicationUser user);
        
        //this will generate the refresh token
        Task<string> GenerateRefreshTokenAsync();

        //this will update the database
        Task SaveRefreshTokenAsync(string userId, string jwtTokenId, string refreshToken,DateTime expiresAt);

        //this will revoke the Refresh token. jwtTokenId and userId will identify that token
        Task<bool> RevokeRefreshTokenAsync(string refreshTokenId);

        Task<(bool IsValid, string? UserId, string? TokenFamilyId, bool TokenReused)> ValidateRefreshTokenAsync(string refreshToken);

    }
}
