﻿using AutoMapper;
using IMS_API.Data;
using IMS_API.Models;
using IMS_API.Services.IServices;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace IMS_API.Services
{
    public class TokenService : ITokenService
    {
        private readonly AppDbContext_APP _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IConfiguration _configuration;


        public TokenService(AppDbContext_APP db, IConfiguration configuration, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _configuration = configuration;
            _userManager = userManager;
        }

        public async Task<string> GenerateJwtTokenAsync(ApplicationUser user)
        {
            //here we need to convert the key to byte array for criptographic operations
            var key = Encoding.ASCII.GetBytes(_configuration.GetSection("JwtSettings")["Secret"]);

            //get all roles for a user
            var roles = await _userManager.GetRolesAsync(user);

            var tokenDecriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.NameIdentifier,user.Id.ToString()),
                    new Claim(ClaimTypes.Email,user.Email.ToString()),
                    new Claim(ClaimTypes.Name,user.Name.ToString()),
                    new Claim(ClaimTypes.Role,roles.FirstOrDefault()),
                    new Claim(JwtRegisteredClaimNames.Jti,Guid.NewGuid().ToString())
                }),
                //the token we are generating valid for 2 minutes
                Expires = DateTime.UtcNow.AddMinutes(2), 

                //this will create the sign in key for the token descriptor
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature) 
            };

            //now we create the token handler which will create the token
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDecriptor);
            return tokenHandler.WriteToken(token);
        }

        public async Task<string> GenerateRefreshTokenAsync()
        {
            //create a rundom number array with 64 byte sign 
            var randomNumber = new byte[64];

            //then we generate rundom numbers 
            using var rng = RandomNumberGenerator.Create();

            //fill the randomNumber array with criptographically secure rundom bytes
            rng.GetBytes(randomNumber);

            //convert this 64 bytes array into a base64 encoded string
            var refreshToken = Convert.ToBase64String(randomNumber);

            //check if the generated token already exists in the database then generate a new refresh token
            var exists = await _db.RefreshTokens.AnyAsync(u=>u.RefreshTokenValue == refreshToken);
            if (exists) 
            {
                return await GenerateRefreshTokenAsync();
            }

            return refreshToken;

        }

        public async Task<bool> RevokeRefreshTokenAsync(string refreshTokenId)
        {
            var storedToken = await _db.RefreshTokens.FirstOrDefaultAsync(u=>u.RefreshTokenValue==refreshTokenId);

            if (storedToken == null)
            {
                return false;
            }
            storedToken.IsValid = false;
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task SaveRefreshTokenAsync(string userId, string jwtTokenId, string refreshToken, DateTime expiresAt)
        {
            var refreshTokenEntity = new RefreshToken
            {
                UserId = userId,
                JwtTokenId = jwtTokenId,
                ExpiresAt = expiresAt,
                RefreshTokenValue = refreshToken,
                IsValid = true
            };

            await _db.RefreshTokens.AddAsync(refreshTokenEntity);
            await _db.SaveChangesAsync();
        }

        public async Task<(bool IsValid, string? UserId, string? TokenFamilyId, bool TokenReused)> ValidateRefreshTokenAsync(string refreshToken)
        {
            var storedToken = await _db.RefreshTokens.FirstOrDefaultAsync(s=>s.RefreshTokenValue==refreshToken);

            //token does not exists in the database
            if(storedToken == null)
            {
                return(false,null,null,false);
            }

            //CRITICAL SECURITY CHECK: Token Reuse Detection
            //if token exists but is marked as invalid, it means someone tried to reuse it
            //this is a wrong indicator of token theft
            if (!storedToken.IsValid)
            {
                //revoke all tokens in this Token Family
                var tokenFamily = await _db.RefreshTokens.Where(u=>u.JwtTokenId==storedToken.JwtTokenId && u.UserId==storedToken.UserId).ToListAsync();

                //if there are any records in tokenFamily then invalidate all tokens in the family 
                if (tokenFamily.Count > 0)
                {
                    foreach (var token in tokenFamily)
                    {
                        token.IsValid = false;
                    }
                    await _db.SaveChangesAsync();

                }

                return (false, storedToken.UserId, storedToken.JwtTokenId,true);
                
            }

            //if this is true that means the token has expired
            if (storedToken.ExpiresAt < DateTime.UtcNow)
            {
                return (false, storedToken.UserId,storedToken.JwtTokenId,false);
            }

            return (true, storedToken.UserId, storedToken.JwtTokenId, false);
        }
    }
}
