﻿using AutoMapper;
using IMS_API.Data;
using IMS_API.Models;
using IMS_API.Services.IServices;
using IMS_DTO.Users;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace IMS_API.Services
{
    public class AuthService : IAuthService
    {
        private readonly AppDbContext_APP _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly ITokenService _tokenService;

        public AuthService(AppDbContext_APP db, IMapper mapper, IConfiguration configuration, 
            UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager, ITokenService tokenService)
        {
            _db = db;
            _mapper = mapper;
            _configuration = configuration;
            _userManager = userManager;
            _roleManager = roleManager;
            _tokenService = tokenService;
        }

        public async Task<bool> IsEmailExistsAsync(string email)
        {
            return await _db.ApplicationUsers.AnyAsync(u => u.Email.ToLower() == email.ToLower());
        }

        public async Task<TokenDTO?> LoginAsync(LoginRequestDTO loginRequestDTO)
        {

            try { 
                var user = await _db.ApplicationUsers.FirstOrDefaultAsync(u => u.Email.ToLower() == loginRequestDTO.Email.ToLower());

                if (user == null) 
                {
                    return null; //user not found
                }

                bool isValid = await _userManager.CheckPasswordAsync(user,loginRequestDTO.Password);

                if (!isValid)
                {
                    return null; //invalid password
                }


                //generate jwt token
                var token = await _tokenService.GenerateJwtTokenAsync(user);

                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadJwtToken(token);
                var jwtTokenId = jwtToken.Claims.FirstOrDefault(u => u.Type == JwtRegisteredClaimNames.Jti)?.Value;



                //roles will be generated in the token 
                //var roles = await _userManager.GetRolesAsync(user);

                //generate new refresh token
                var newRefreshToken = await _tokenService.GenerateRefreshTokenAsync();

                //set expiration time for 5 minutes for access token
                var refreshTokenExpire = DateTime.UtcNow.AddMinutes(5);

                await _tokenService.SaveRefreshTokenAsync(user.Id, jwtTokenId, newRefreshToken, refreshTokenExpire);

                TokenDTO tokenDTO =  new TokenDTO
                {
                    AccessToken = token,
                    RefreshToken=newRefreshToken,
                    ExpiresAt = jwtToken.ValidTo //this property will be populated in TokenService --> Expires = DateTime.UtcNow.AddMinutes(2)
                };

                //loginResponseDTO.UserDTO.Role = roles.FirstOrDefault()?? "InventoryUser";
                return tokenDTO;

            }
            catch(Exception ex)
            {
                throw new InvalidOperationException("An unexpected error ocured during user login", ex);
            }

        }


        public async Task<UserDTO?> RegisterAsync(RegisterationRequestDTO registerationRequestDTO)
        {
            try { 
                if (await IsEmailExistsAsync(registerationRequestDTO.Email))
                {
                    throw new InvalidOperationException($"User with email '{registerationRequestDTO.Email}' already exists");
                }

                ApplicationUser user = new()
                {
                    Email = registerationRequestDTO.Email,
                    Name = registerationRequestDTO.Name,
                    UserName = registerationRequestDTO.Email,
                    NormalizedEmail = registerationRequestDTO.Email.ToUpper(),
                    EmailConfirmed = true
                };

                var result = await _userManager.CreateAsync(user, registerationRequestDTO.Password);
                if (!result.Succeeded)
                {
                    var errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    throw new InvalidOperationException($"User Registration failed: {errors}");
                }

                var role = string.IsNullOrEmpty(registerationRequestDTO.Role) ? "InventoryUser" : registerationRequestDTO.Role;

                //if the role does not exists then create the role
                //once the role created we can asign the role to the user
                if(!await _roleManager.RoleExistsAsync(role))
                {
                    await _roleManager.CreateAsync(new IdentityRole(role));
                }

                // for multiple roles for a user we need to use AddToRolesAsync. For one role per user we can use AddToRoleAsync  
                await _userManager.AddToRoleAsync(user, role);

                //when we use the mapping the role will not be populated  
                var userDto = _mapper.Map<UserDTO?>(user);

                userDto.Role=role;

                return userDto;
            }
            catch(Exception ex)
            {
                throw new InvalidOperationException("An unexpected error ocured during user registeration",ex);
            }
        }


        public async Task<TokenDTO?> RefreshAccessTokenAsync(RefreshTokenRequestDTO refreshTokenRequestDTO)
        {
            try
            {
                if (string.IsNullOrEmpty(refreshTokenRequestDTO.RefreshToken)) 
                {
                    return null;
                }

                //validate the refresh token. 
                var (isValid, userId, tokenFamilyId, tokenReused) = await _tokenService.ValidateRefreshTokenAsync(refreshTokenRequestDTO.RefreshToken);


                //we nknos that if the token has been reused. Token Reuse detection
                if (tokenReused)
                {
                    return null;
                }


                //check if token is valid or expired
                if(!isValid || string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(tokenFamilyId))
                {
                    return null;
                }

                //if everithing is valid then get user from database
                var user = await _db.ApplicationUsers.FindAsync(userId);
                if(user == null)
                {
                    return null;
                }

                //revoke old refresh token
                await _tokenService.RevokeRefreshTokenAsync(refreshTokenRequestDTO.RefreshToken);


                //generate new access token and refresh token 

                //generate jwt token
                var token = await _tokenService.GenerateJwtTokenAsync(user);

                var tokenHandler = new JwtSecurityTokenHandler();
                var jwtToken = tokenHandler.ReadJwtToken(token);

                //generate new refresh token
                var newRefreshToken = await _tokenService.GenerateRefreshTokenAsync();

                //set expiration time for 5 minutes for access token
                var refreshTokenExpire = DateTime.UtcNow.AddMinutes(5);

                await _tokenService.SaveRefreshTokenAsync(user.Id, tokenFamilyId, newRefreshToken, refreshTokenExpire);

                TokenDTO tokenDTO = new TokenDTO
                {
                    AccessToken = token,
                    RefreshToken = newRefreshToken,
                    ExpiresAt = jwtToken.ValidTo //this property will be populated in TokenService --> Expires = DateTime.UtcNow.AddMinutes(2)
                };

                //loginResponseDTO.UserDTO.Role = roles.FirstOrDefault()?? "InventoryUser";
                return tokenDTO;

            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("An unexpected error ocured during token refresh", ex);
            }
        }

    }
}
