﻿using Asp.Versioning;
using AutoMapper;
using IMS_API.Data;
using IMS_API.Models;
using IMS_DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Diagnostics.Eventing.Reader;
using System.Text;
using System.Globalization;
using IMS_DTO.Inventory.Pullback;

namespace IMS_API.Controllers.V1
{
    [Route("api/v{version:apiVersion}/PullbackExclList")]
    [ApiVersion("1.0")]  
    [ApiController]
    //[Route("api/PullbackExclList")]
    //[Authorize(Roles = "Customer,Admin")]
    public class PullbackExclListAPIController : ControllerBase
    {
        private readonly AppDbContext_INV _db;
        private readonly IMapper _mapper;

        public PullbackExclListAPIController(AppDbContext_INV db,IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }


        [HttpGet]
        [Authorize]
        //[Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(ApiResponse<IEnumerable<PullbackExclListDto>>),StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<ApiResponse<IEnumerable<PullbackExclListDto>>>> GetPullbackExclList(
            [FromQuery] string? filterBy, [FromQuery] string? filterQuery,
            [FromQuery] string? sortBy, [FromQuery] string? sortOrder = "asc", 
            [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {

            if (page<1) page = 1;
            if (pageSize < 1) pageSize = 10;
            if (pageSize > 100) pageSize = 100;


            //------------------------------------------------------------------------------filtering logic
            var pQuery = _db.INV_PULLBACK_EXCLUSION_LIST.AsQueryable();
            if (!string.IsNullOrEmpty(filterQuery) && !string.IsNullOrEmpty(filterBy))
            {
                switch (filterBy.ToLower())
                {
                    case "etype":
                        pQuery = pQuery.Where(u => u.ETYPE.ToLower().Contains(filterQuery.ToLower()));
                        break;
                    case "evalue":
                        pQuery = pQuery.Where(u => u.EVALUE.ToLower().Contains(filterQuery.ToLower()));
                        break;
                }
            }

            //------------------------------------------------------------------------------sorting logic
            if (!string.IsNullOrEmpty(sortBy))
            {
                var isDescending = sortOrder?.ToLower() == "desc";

                pQuery = sortBy.ToLower() switch
                {
                    "etype" => isDescending ? pQuery.OrderByDescending(u => u.ETYPE) : pQuery.OrderBy(u => u.ETYPE),
                    "evalue" => isDescending ? pQuery.OrderByDescending(u => u.EVALUE) : pQuery.OrderBy(u => u.EVALUE),
                    "id" => isDescending ? pQuery.OrderByDescending(u => u.ID) : pQuery.OrderBy(u => u.ID),
                    _=> pQuery.OrderBy(u=>u.ID) //add the default value which is asc
                };
            }
            else
            {
                pQuery = pQuery.OrderBy(u => u.ID);
            }

            //------------------------------------------------------------------------------pagination logic
            var skip = (page - 1) * pageSize;

            //build a custom response message
            var totalCount = await pQuery.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalCount / pageSize);

            var pullbExclList = await pQuery.Skip(skip).Take(pageSize).ToListAsync();
            var dtoResponsePExcl = _mapper.Map<List<PullbackExclListDto>>(pullbExclList);

            var messageBuilder = new StringBuilder();

            messageBuilder.Append($"Succesfully retreived {dtoResponsePExcl.Count} exclusions");
            messageBuilder.Append($"Page {page} of {totalPages}, {totalCount} total records");

            //------------------------------------------------------------------------------add message to Filter
            if (!string.IsNullOrEmpty(filterQuery) && !string.IsNullOrEmpty(filterBy))
            {
                //if sortOrder is null convert to lower and if not populated then set asc as default
                messageBuilder.Append($"filtered by {filterBy}: '{filterQuery}'");
            }

            //------------------------------------------------------------------------------add message to the Sorting
            if (!string.IsNullOrEmpty(sortBy))
            {
                messageBuilder.Append($"sorted by {sortBy}: '{sortOrder?.ToLower() ?? "asc"}'");
            }

            //------------------------------------------------------------------------------add pagination details to response headers
            Response.Headers.Append("X-Pagination-CurrentPage", page.ToString());
            Response.Headers.Append("X-Pagination-PageSize", pageSize.ToString());
            Response.Headers.Append("X-Pagination-TotalCount", totalCount.ToString());
            Response.Headers.Append("X-Pagination-TotalPages", totalPages.ToString());


            var response = ApiResponse<IEnumerable<PullbackExclListDto>>.Ok(dtoResponsePExcl, messageBuilder.ToString());
            return Ok(response);

        }


        [HttpGet("{id:int}")]
        //[AllowAnonymous]
        [ProducesResponseType(typeof(ApiResponse<PullbackExclListDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ApiResponse<PullbackExclListDto>>> GetPullbackExclListById(int id)
        {
            try
            {
                if(id <= 0)
                {
                    return NotFound(ApiResponse<object>.NotFound("Id must be greater than 0"));

                    //return new ApiResponse<PullbackExclListDto>()
                    //{
                    //    StatusCode = 400,
                    //    Errors = "Id must be greater than 0",
                    //    Success = false,
                    //    Message = "Bad Request"
                    //};

                    //return BadRequest("Id must be greater than 0");
                }

                var pullExclList = await _db.INV_PULLBACK_EXCLUSION_LIST.FirstOrDefaultAsync(i => i.ID == id);
                if(pullExclList == null)
                {
                    //return NotFound($"PullbackExclList with Id {id} was not found.");
                    return NotFound(ApiResponse<object>.NotFound($"PullbackExclList with Id {id} was not found."));
                }

                var response = _mapper.Map<PullbackExclListDto>(pullExclList);
                return Ok(ApiResponse<PullbackExclListDto>.Ok(response, "Records retreived successfully"));

                //return new ApiResponse<PullbackExclListDto>()
                //{
                //    StatusCode = 200,
                //    Success = true,
                //    Message = "Records retreived successfully",
                //    Data = _mapper.Map<PullbackExclListDto>(pullExclList)
                //};

                //return Ok(_mapper.Map<PullbackExclListDto>(pullExclList));
            }
            catch (Exception ex)
            {
                //return StatusCode(StatusCodes.Status500InternalServerError, $"An error ocured while retreiving PullbackExclList with Id {id}: {ex.Message}  ");
                var errorResponse = ApiResponse<object>.Error(500, $"An error ocured while retreiving PullbackExclList with Id {id}:", ex.Message);
                return StatusCode(500, errorResponse);
            }
        }


        [HttpPost]
        //[Authorize(Roles = "Admin,Customer")]
        [ProducesResponseType(typeof(ApiResponse<PullbackExclListDto>), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<ApiResponse<PullbackExclListDto>>> CreatePullbackExclList(PullbackExclListCreateDto pullbExclListCreateDto)
        {
            try
            {
                if (pullbExclListCreateDto == null)
                {
                    return BadRequest(ApiResponse<object>.BadRequest("Pullback Exclusion data required"));
                    //return BadRequest("Pullback Exclusion data required");
                }

                //validation for duplicated lines
                var duplicateList = await _db.INV_PULLBACK_EXCLUSION_LIST.FirstOrDefaultAsync(u => u.ETYPE == pullbExclListCreateDto.ETYPE
                && u.EVALUE == pullbExclListCreateDto.EVALUE);

                if (duplicateList != null)
                {
                    return Conflict(ApiResponse<object>.Conflict($"PullbExclList with the type '{pullbExclListCreateDto.ETYPE}' and value '{pullbExclListCreateDto.EVALUE}' already exists!"));
                    
                    //this is returning a 409 
                    //return Conflict($"PullbExclList with the type '{pullbExclListCreateDto.ETYPE}' and value '{pullbExclListCreateDto.EVALUE}' already exists!");
                }

                PullbackExclList pullExclList = _mapper.Map<PullbackExclList>(pullbExclListCreateDto);

                await _db.INV_PULLBACK_EXCLUSION_LIST.AddAsync(pullExclList);
                await _db.SaveChangesAsync();

                //return where that was created. First parameter is the name of the method.
                //Second will be the value where it has been created. 
                //Third parameter will be the complete pullExclList object with all properties when return
                //return CreatedAtAction(nameof(CreatePullbackExclList), new { id = pullExclList.ID }, _mapper.Map<PullbackExclListDto>(pullExclList));

                var response = ApiResponse<PullbackExclListDto>.CreatedAt(_mapper.Map<PullbackExclListDto>(pullExclList), "PullbackExclLIst created successfully");
                return CreatedAtAction(nameof(CreatePullbackExclList), new { id = pullExclList.ID }, response);

            }
            catch (Exception ex)
            {
                var errorResponse = ApiResponse<object>.Error(500, "An error ocured while creating PullbackExclList:", ex.Message);
                return StatusCode(500, errorResponse);
            }
        }


        [HttpPut("{id:int}")]
        [Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(ApiResponse<PullbackExclListDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status409Conflict)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ApiResponse<PullbackExclListDto>>> UpdatePullbackExclList(int id, PullbackExclListUpdateDto pullbExclListUpdateDto)
        {
            try
            {
                if (pullbExclListUpdateDto == null)
                {
                    return BadRequest(ApiResponse<object>.BadRequest("Pullback Exclusion data required!"));
                    //return BadRequest("Pullback Exclusion data required!");
                }

                if(id != pullbExclListUpdateDto.ID)
                {
                    return BadRequest(ApiResponse<object>.BadRequest("PullbackExclusion ID in URL does not match PullbackExclusion ID in request body!"));
                    //return BadRequest("PullbackExclusion ID in URL does not match PullbackExclusion ID in request body!");
                }

                var existingPullExcl = await _db.INV_PULLBACK_EXCLUSION_LIST.FirstOrDefaultAsync(u=>u.ID==id);

                if(existingPullExcl == null)
                {
                    return NotFound(ApiResponse<object>.NotFound($"PullbExclList with Id {id} was not found!"));
                    //return NotFound($"PullbExclList with Id {id} was not found!");
                }

                //validation for duplicated lines
                var duplicateList = await _db.INV_PULLBACK_EXCLUSION_LIST.FirstOrDefaultAsync(u=>u.ETYPE == pullbExclListUpdateDto.ETYPE
                && u.EVALUE == pullbExclListUpdateDto.EVALUE && u.ID==id && u.EXCL == pullbExclListUpdateDto.EXCL); 

                if(duplicateList != null)
                {
                    return Conflict(ApiResponse<object>.Conflict($"PullbExclList with the type '{pullbExclListUpdateDto.ETYPE}' and value '{pullbExclListUpdateDto.EVALUE}' already exists!"));
                    //this is returning a 409 
                    //return Conflict($"PullbExclList with the type '{pullbExclListUpdateDto.ETYPE}' and value '{pullbExclListUpdateDto.EVALUE}' already exists!");
                }

                _mapper.Map(pullbExclListUpdateDto,existingPullExcl);
                await _db.SaveChangesAsync();

                //return Ok(pullbExclListUpdateDto);

                //here we need to update back PullbackExclListUpdateDto to PullbackExclListDto, so we need to add that to Program.cs
                var response = ApiResponse<PullbackExclListDto>.Ok(_mapper.Map<PullbackExclListDto>(pullbExclListUpdateDto), "PullbackExclList updated successfully!");
                return Ok(response);

            }
            catch (Exception ex)
            {
                var errorResponse = ApiResponse<object>.Error(500, "An error ocured while updating PullbackExclList:", ex.Message);
                return StatusCode(500, errorResponse);
            }
        }


        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status404NotFound)]
        public async Task<ActionResult<ApiResponse<object>>> DeletePullbackExclList(int id)
        {
            try
            {

                var existingPullExcl = await _db.INV_PULLBACK_EXCLUSION_LIST.FirstOrDefaultAsync(u => u.ID == id);

                if (existingPullExcl == null)
                {
                    return NotFound(ApiResponse<object>.NotFound($"PullbExclList with Id {id} was not found!"));
                    //return NotFound($"PullbExclList with Id {id} was not found!");
                }

                _db.INV_PULLBACK_EXCLUSION_LIST.Remove(existingPullExcl);
                await _db.SaveChangesAsync();

                var response = ApiResponse<object>.NoContent("PullbackExcl deleted successfully!");
                return Ok(response);

                //return NoContent();
            }
            catch (Exception ex)
            {
                var errorResponse = ApiResponse<object>.Error(500, "An error ocured while deleting PullbackExclList:", ex.Message);
                return StatusCode(500, errorResponse);
            }
        }


        [HttpPost("upload-csv")]
        [Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(ApiResponse<PullbackExclListCsvUploadResultDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiResponse<object>), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<ApiResponse<PullbackExclListCsvUploadResultDto>>> UploadPullbackExclListCsv(IFormFile? file)
        {
            try
            {
                //------------------------------------------------------------------------------basic file validation
                if (file == null || file.Length == 0)
                {
                    return BadRequest(ApiResponse<object>.BadRequest("A CSV file is required."));
                }

                if (!Path.GetExtension(file.FileName).Equals(".csv", StringComparison.OrdinalIgnoreCase))
                {
                    return BadRequest(ApiResponse<object>.BadRequest("Only .csv files are supported."));
                }

                var result = new PullbackExclListCsvUploadResultDto();
                var rowsToInsert = new List<PullbackExclList>();

                //key used to detect duplicates within the file itself (ETYPE|EVALUE, case-insensitive)
                var seenInFile = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                //------------------------------------------------------------------------------load existing keys from DB so we don't insert dupes
                var existingKeys = await _db.INV_PULLBACK_EXCLUSION_LIST
                    .Select(e => (e.ETYPE + "|" + e.EVALUE))
                    .ToListAsync();
                var existingKeySet = new HashSet<string>(existingKeys, StringComparer.OrdinalIgnoreCase);

                using var reader = new StreamReader(file.OpenReadStream());

                int rowNumber = 0;
                bool headerSkipped = false;

                while (!reader.EndOfStream)
                {
                    var line = await reader.ReadLineAsync();
                    rowNumber++;

                    if (string.IsNullOrWhiteSpace(line))
                    {
                        continue;
                    }

                    var fields = ParseCsvLine(line);

                    //------------------------------------------------------------------------------detect and skip an optional header row (ETYPE,EVALUE,EXCL)
                    if (!headerSkipped)
                    {
                        headerSkipped = true;
                        if (fields.Count >= 2 &&
                            fields[0].Trim().Equals("ETYPE", StringComparison.OrdinalIgnoreCase) &&
                            fields[1].Trim().Equals("EVALUE", StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }
                    }

                    result.TotalRows++;

                    if (fields.Count < 3)
                    {
                        result.ErrorCount++;
                        result.Rows.Add(new PullbackExclListCsvRowResultDto
                        {
                            RowNumber = rowNumber,
                            Status = "Error",
                            Message = "Row must contain ETYPE, EVALUE and EXCL columns."
                        });
                        continue;
                    }

                    var etype = fields[0].Trim();
                    var evalue = fields[1].Trim();
                    var exclRaw = fields[2].Trim();

                    if (string.IsNullOrEmpty(etype) || string.IsNullOrEmpty(evalue))
                    {
                        result.ErrorCount++;
                        result.Rows.Add(new PullbackExclListCsvRowResultDto
                        {
                            RowNumber = rowNumber,
                            ETYPE = etype,
                            EVALUE = evalue,
                            Status = "Error",
                            Message = "ETYPE and EVALUE are required."
                        });
                        continue;
                    }

                    if (!TryParseExcl(exclRaw, out var excl))
                    {
                        result.ErrorCount++;
                        result.Rows.Add(new PullbackExclListCsvRowResultDto
                        {
                            RowNumber = rowNumber,
                            ETYPE = etype,
                            EVALUE = evalue,
                            Status = "Error",
                            Message = $"EXCL value '{exclRaw}' is not valid. Use Y/N, true/false or 1/0."
                        });
                        continue;
                    }

                    var key = $"{etype}|{evalue}";

                    if (existingKeySet.Contains(key) || !seenInFile.Add(key))
                    {
                        result.SkippedCount++;
                        result.Rows.Add(new PullbackExclListCsvRowResultDto
                        {
                            RowNumber = rowNumber,
                            ETYPE = etype,
                            EVALUE = evalue,
                            Status = "Skipped",
                            Message = "A record with this ETYPE and EVALUE already exists."
                        });
                        continue;
                    }

                    rowsToInsert.Add(new PullbackExclList
                    {
                        ETYPE = etype,
                        EVALUE = evalue,
                        EXCL = excl
                    });

                    result.InsertedCount++;
                    result.Rows.Add(new PullbackExclListCsvRowResultDto
                    {
                        RowNumber = rowNumber,
                        ETYPE = etype,
                        EVALUE = evalue,
                        Status = "Inserted",
                        Message = "Row queued for insert."
                    });
                }

                if (rowsToInsert.Count > 0)
                {
                    await _db.INV_PULLBACK_EXCLUSION_LIST.AddRangeAsync(rowsToInsert);
                    await _db.SaveChangesAsync();
                }

                var message = $"Processed {result.TotalRows} row(s): {result.InsertedCount} inserted, " +
                    $"{result.SkippedCount} skipped, {result.ErrorCount} failed.";

                var response = ApiResponse<PullbackExclListCsvUploadResultDto>.Ok(result, message);
                return Ok(response);
            }
            catch (Exception ex)
            {
                var errorResponse = ApiResponse<object>.Error(500, "An error ocured while uploading the CSV file:", ex.Message);
                return StatusCode(500, errorResponse);
            }
        }


        //------------------------------------------------------------------------------small helper to split a CSV line, respecting quoted fields
        private static List<string> ParseCsvLine(string line)
        {
            var fields = new List<string>();
            var current = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                var c = line[i];

                if (inQuotes)
                {
                    if (c == '"')
                    {
                        if (i + 1 < line.Length && line[i + 1] == '"')
                        {
                            current.Append('"');
                            i++;
                        }
                        else
                        {
                            inQuotes = false;
                        }
                    }
                    else
                    {
                        current.Append(c);
                    }
                }
                else
                {
                    if (c == '"')
                    {
                        inQuotes = true;
                    }
                    else if (c == ',')
                    {
                        fields.Add(current.ToString());
                        current.Clear();
                    }
                    else
                    {
                        current.Append(c);
                    }
                }
            }

            fields.Add(current.ToString());
            return fields;
        }


        //------------------------------------------------------------------------------small helper to interpret Y/N, true/false and 1/0 as boolean
        private static bool TryParseExcl(string value, out bool excl)
        {
            switch (value.Trim().ToLowerInvariant())
            {
                case "y":
                case "yes":
                case "true":
                case "1":
                    excl = true;
                    return true;
                case "n":
                case "no":
                case "false":
                case "0":
                    excl = false;
                    return true;
                default:
                    excl = false;
                    return false;
            }
        }


    }
}
