﻿using Asp.Versioning;
using AutoMapper;
using IMS_API.Data;
using IMS_API.Models;
using IMS_DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections;

namespace IMS_API.Controllers.V2
{
    [Route("api/v{version:apiVersion}/PullbackExclList")]
    [ApiVersion("2.0")]
    [ApiController]
    //[Authorize(Roles = "Customer,Admin")]
    public class PullbackExclListAPIController : ControllerBase
    {
        private readonly AppDbContext_INV _db;
        private readonly IMapper _mapper;

        public PullbackExclListAPIController(AppDbContext_INV db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }


        [HttpGet]
        public async Task<ActionResult<String>> GetPullbackExclList()
        {

            return Ok("Testing V2");
        }


        [HttpGet("{id:int}")]
        public async Task<ActionResult<String>> GetPullbackExclListById(int id)
        {
            return Ok("Testing V2 with id:" + id);
        }





    }
}
