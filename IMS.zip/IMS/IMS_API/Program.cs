using IMS_API.Data;
using IMS_API.Models;
using IMS_API.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using Scalar.AspNetCore;
using System.Text;
using System.Security.Claims;
using Asp.Versioning;
using Asp.Versioning.ApiExplorer;
using IMS_DTO.Users;
using IMS_DTO.Inventory.Pullback;
using Microsoft.AspNetCore.Identity;
using IMS_API.Services.IServices;

var builder = WebApplication.CreateBuilder(args);
var key = Encoding.ASCII.GetBytes(builder.Configuration.GetSection("JwtSettings")["Secret"]);
//var key = builder.Configuration.GetValue<string>("ApiSettings:Secret");

builder.Services.AddIdentity<ApplicationUser, IdentityRole>().AddEntityFrameworkStores<AppDbContext_APP>();

//configure authentication scheme
//and JwtBearer with some options
builder.Services.AddAuthentication(option =>
{
    option.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    option.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    option.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters //this will tels all parameters to validate if the token is valid or not 
    {
        ValidateIssuerSigningKey = true, 
        IssuerSigningKey = new SymmetricSecurityKey(key), //this will validate the ValidateIssuerSigningKey
        ValidateIssuer = false,
        ValidateAudience = false,
        ValidateLifetime = true, //this will check wether the Jwt token has expired or not using the expiration date
        ClockSkew = TimeSpan.Zero, 
        NameClaimType = ClaimTypes.Name,
        RoleClaimType = ClaimTypes.Role
    };
});

builder.Services.AddScoped<ITokenService, TokenService>();

builder.Services.AddApiVersioning(options =>
{
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.ReportApiVersions = true;
}).AddApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;
});

//builder.Services.AddApiVersioning();


builder.Services.AddCors();

builder.Services.AddDbContext<AppDbContext_APP>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConnStrIMS_APP"),
        sqlServerOptionsAction: sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
            maxRetryCount: 10,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null);
            sqlOptions.MigrationsAssembly("IMS_API")
              .MigrationsHistoryTable("__EFMigrationsHistory_APP");
        });
});

builder.Services.AddDbContext<AppDbContext_INV>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConnStrIMS_INV"),
        sqlServerOptionsAction: sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
            maxRetryCount: 10,
            maxRetryDelay: TimeSpan.FromSeconds(30),
            errorNumbersToAdd: null);
            sqlOptions.MigrationsAssembly("IMS_API")
              .MigrationsHistoryTable("__EFMigrationsHistory_INV");
        });
});



// Add services to the container.

builder.Services.AddControllers();


var buildProvider = builder.Services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();

    foreach (var description in buildProvider.ApiVersionDescriptions)
    {
        var versionName = description.GroupName;
        var versionNumber = description.ApiVersion.ToString();
        var displayName = $"IMS API -- {versionNumber}";


        // here if we adding versionName openapi will knows we are adding two documnts  
        builder.Services.AddOpenApi(versionName,options =>
        {
            options.AddDocumentTransformer((document, context, cancellationToken) =>
            {

                document.Info = new OpenApiInfo
                {
                    Title = "IMS API",
                    Version = versionName,
                    Description = displayName,
                    Contact = new OpenApiContact
                    {
                        Name = "G Simon",
                        Email = "gabor.simon@gsfgroup.com"
                    }
                };

                document.Components ??= new(); //check if document.Components does not exist create new instance
                document.Components.SecuritySchemes = new Dictionary<string, IOpenApiSecurityScheme>
                {
                    ["Bearer"] = new OpenApiSecurityScheme
                    {
                        Type = SecuritySchemeType.Http,
                        Scheme = "bearer",
                        BearerFormat = "JWT",
                        Description = "Enter JWT Bearer token"
                    }
                };
                //in order to use this document globaly we need to add
                document.Security =
                [
                    new OpenApiSecurityRequirement
                    {
                        { new OpenApiSecuritySchemeReference("Bearer"),new List<string>() }
                    }
                ];

                return Task.CompletedTask;
            });
        });


}


/*
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi(options =>
{
    options.AddDocumentTransformer((document, context, cancellationToken) =>
    {
        document.Components ??= new(); //check if document.Components does not exist create new instance
        document.Components.SecuritySchemes = new Dictionary<string, IOpenApiSecurityScheme>
        {
            ["Bearer"] = new OpenApiSecurityScheme
            {
                Type = SecuritySchemeType.Http,
                Scheme = "bearer",
                BearerFormat = "JWT",
                Description = "Enter JWT Bearer token"
            }
        };
        //in order to use this document globaly we need to add
        document.Security =
        [
            new OpenApiSecurityRequirement
            {
                { new OpenApiSecuritySchemeReference("Bearer"),new List<string>() }
            }
        ];

        return Task.CompletedTask;
    });
});
*/




builder.Services.AddAutoMapper(options =>
{
    options.CreateMap<PullbackExclList, PullbackExclListCreateDto>().ReverseMap();
    options.CreateMap<PullbackExclList, PullbackExclListUpdateDto>().ReverseMap();
    options.CreateMap<PullbackExclList, PullbackExclListDto>().ReverseMap();
    options.CreateMap<PullbackExclListUpdateDto, PullbackExclListDto>().ReverseMap();
    options.CreateMap<ApplicationUser, UserDTO>().ReverseMap();
});

builder.Services.AddScoped<IAuthService, AuthService>();

var app = builder.Build();

/*
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference();
}
*/

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi("/openapi/{documentName}.json");
    var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

    app.MapScalarApiReference(options =>
    {
        options.Title = "IMS API";
        var sortedVersion = provider.ApiVersionDescriptions.OrderBy(v => v.ApiVersion).ToList();

        foreach(var description in sortedVersion)
        {
            var versionName = description.GroupName;
            var versionNumber = description.ApiVersion.ToString();
            var displayName = $"IMS API -- {versionNumber}";
            var isDefault = description.ApiVersion.Equals(new ApiVersion(1.0));
            options.AddDocument(versionName, displayName, $"/openapi/{versionName}.json", isDefault);
        }
    });
}



//here any origin, header or any method can access our API endpoint 
app.UseCors(o=>o.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod().WithExposedHeaders("*"));
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
