﻿
using IMS_API.Models;
using Microsoft.EntityFrameworkCore;

namespace IMS_API.Data
{
    public class AppDbContext_INV(DbContextOptions<AppDbContext_INV> options) : DbContext(options)
    {
        public DbSet<PullbackExclList> INV_PULLBACK_EXCLUSION_LIST { get; set; }
    }
}
