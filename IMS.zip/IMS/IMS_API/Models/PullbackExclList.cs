﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IMS_API.Models
{
    public partial class PullbackExclList
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        [Required]
        public string ETYPE { get; set; }
        [Required]
        public string EVALUE { get; set; }
        [Required]
        public bool EXCL { get; set; }
    }
}
