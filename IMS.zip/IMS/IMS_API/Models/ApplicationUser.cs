﻿using Microsoft.AspNetCore.Identity;

namespace IMS_API.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string Name { get; set; }
    }
}
