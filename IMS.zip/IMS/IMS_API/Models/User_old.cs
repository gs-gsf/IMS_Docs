﻿using System.ComponentModel.DataAnnotations;

namespace IMS_API.Models
{
    public partial class User_old
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [EmailAddress]
        public required string UEMAIL { get; set; }

        [Required]
        [MaxLength(100)]
        public required string UNAME { get; set; }

        [Required]
        public required string UPASSWORD { get; set; }

        [Required]
        [MaxLength(50)]
        //public required string UROLE { get; set; } = "Customer";
        public required string UROLE { get; set; } = "InventoryUser";

        public DateTime? CREATED_DATE { get; set; }
        public DateTime? UPDATED_DATE { get; set; }
    }
}
