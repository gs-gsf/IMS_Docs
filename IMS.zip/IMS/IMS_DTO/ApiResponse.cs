﻿namespace IMS_DTO
{
    //TData can be any name and will return any type of objects dynamically
    public class ApiResponse<TData>
    {
        public bool Success { get; set; }
        public int StatusCode { get; set; }
        public string Message { get; set; } = string.Empty;
        public TData? Data { get; set; } //TData will be the data that API will be returning back
        public object? Errors { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;


        //this will create a dynamic API response  
        public static ApiResponse<TData> Create(bool success, int statusCode,string message, TData? data=default, object? errors = null)
        {
            return new ApiResponse<TData>
            {
                Success = success,
                StatusCode = statusCode,
                Message = message,
                Data = data,
                Errors = errors
            };
        }

        //this will return Ok 
        public static ApiResponse<TData> Ok(TData data, string message) =>
            Create(true, 200, message,data);

        //this will return CreatedAt 
        public static ApiResponse<TData> CreatedAt(TData data, string message) =>
             Create(true, 201, message, data);

        //this will return NoContent 
        public static ApiResponse<TData> NoContent(string message = "Operation completed successfully") =>
           Create(true, 204, message);

        //this will return NotFound 
        public static ApiResponse<TData> NotFound(string message = "Resource not found") =>
            Create(false, 404, message);

        //this will return BadRequest 
        public static ApiResponse<TData> BadRequest(string message, object? errors = null) =>
            Create(false, 400, message,errors:errors);

        //this will return Conflict if record already exists
        public static ApiResponse<TData> Conflict(string message) =>
            Create(false, 409, message);


        //this will be for a generic errors
        public static ApiResponse<TData> Error(int statusCode, string message, object? errors = null) =>
           Create(false, statusCode, message, errors: errors);

    }
}
