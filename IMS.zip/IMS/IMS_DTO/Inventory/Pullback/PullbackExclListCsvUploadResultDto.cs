﻿namespace IMS_DTO.Inventory.Pullback
{
    public class PullbackExclListCsvUploadResultDto
    {
        public int TotalRows { get; set; }
        public int InsertedCount { get; set; }
        public int SkippedCount { get; set; }
        public int ErrorCount { get; set; }
        public List<PullbackExclListCsvRowResultDto> Rows { get; set; } = new();
    }
}
