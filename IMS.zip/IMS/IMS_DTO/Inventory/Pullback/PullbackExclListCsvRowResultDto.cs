﻿namespace IMS_DTO.Inventory.Pullback
{
    public class PullbackExclListCsvRowResultDto
    {
        public int RowNumber { get; set; }
        public string? ETYPE { get; set; }
        public string? EVALUE { get; set; }
        public string Status { get; set; } = string.Empty; // Inserted, Skipped, Error
        public string Message { get; set; } = string.Empty;
    }
}
