﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IMS_DTO.Inventory.Pullback
{
    public class PullbackExclListUpdateDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int ID { get; set; }
        [Required]
        public string ETYPE { get; set; }
        [Required]
        public string EVALUE { get; set; }
        [Required]
        public bool EXCL { get; set; }
    }
}
