﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IMS_DTO.Inventory.Pullback
{
    public class PullbackExclListDto
    {
        public int ID { get; set; }
        public string ETYPE { get; set; }
        public string EVALUE { get; set; }
        public bool EXCL { get; set; }
    }
}
