﻿namespace IMS_DTO.Users
{
    public class TokenDTO
    {
        //this will be the response when everithing is successfull
        public string? AccessToken { get; set; }
        public string? RefreshToken { get; set; }
        public DateTime? ExpiresAt { get; set; }
    }
}
