﻿using System.ComponentModel.DataAnnotations;

namespace IMS_DTO.Users
{
    public class RegisterationRequestDTO
    {
        [Required]
        [EmailAddress]
        public required string Email { get; set; }

        [Required]
        [MaxLength(100)]
        public required string Name { get; set; }

        [Required]
        public required string Password { get; set; }

        [MaxLength(50)]
        //public  string UROLE { get; set; } = "Customer";
        public string Role { get; set; } = "InventoryUser";
    }
}
