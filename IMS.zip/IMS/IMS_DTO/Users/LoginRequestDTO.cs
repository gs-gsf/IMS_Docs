﻿using System.ComponentModel.DataAnnotations;

namespace IMS_DTO.Users
{
    public class LoginRequestDTO
    {
        [Required]
        [EmailAddress]
        public required string Email { get; set; }

        [Required]
        public required string Password { get; set; }
    }
}
