﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IMS_DTO.Users
{
    public class RefreshTokenRequestDTO
    {
        public string? RefreshToken { get; set; }
    }
}
