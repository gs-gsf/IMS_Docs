using AutoMapper;
using IMS_DTO;
using IMS_WEB.Models;
using IMS_WEB.Services.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace IMS_WEB.Controllers
{
    public class HomeController : Controller
    {
        //private readonly IPullbExclListService _pullbExclListService;
        //private readonly IMapper _mapper;

        //public HomeController(IPullbExclListService pullbExclListService,IMapper mapper)
        //{
        //    _pullbExclListService = pullbExclListService;   
        //    _mapper = mapper;
        //}


        public async Task<IActionResult> Index()
        {
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
