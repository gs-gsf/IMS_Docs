using AutoMapper;
using IMS_DTO;
using IMS_DTO.Inventory.Pullback;
using IMS_WEB.Models;
using IMS_WEB.Services.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Diagnostics;
using System.Globalization;

namespace IMS_WEB.Controllers
{
    public class PullbackExclListController : Controller
    {
        private readonly IPullbExclListService _pullbExclListService;
        private readonly IMapper _mapper;

        public PullbackExclListController(IPullbExclListService pullbExclListService,IMapper mapper)
        {
            _pullbExclListService = pullbExclListService;   
            _mapper = mapper;
        }


        public async Task<IActionResult> Index(
            string? filterBy,
            string? filterQuery,
            string? sortBy,
            string? sortOrder,
            int page = 1,
            int pageSize = 10)
        {
            List<PullbackExclListDto> pullbackExclLists = new();

            try
            {
                var response = await _pullbExclListService.GetAllAsync<ApiResponse<List<PullbackExclListDto>>>(filterBy,
                        filterQuery,
                        sortBy,
                        sortOrder,
                        page,
                        pageSize);
                if(response!=null && response.Success && response.Data != null)
                {
                    pullbackExclLists = response.Data;
                }
            }
            catch (Exception ex) 
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }

            ViewBag.FilterBy = filterBy;
            ViewBag.FilterQuery = filterQuery;
            ViewBag.SortBy = sortBy;
            ViewBag.SortOrder = sortOrder;
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;

            return View(pullbackExclLists);
        }



        //[Authorize(Roles = "Admin,Customer")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        //[Authorize(Roles = "Admin,Customer")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PullbackExclListCreateDto createDto)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }


            try
            {
                // Convert bool to "Y" / "N"
                var exclValue = createDto.EXCL ? "Y" : "N";

                // Replace the DTO value with the converted one
                createDto.EXCL = exclValue == "Y";

                var response = await _pullbExclListService.CreateAsync<ApiResponse<PullbackExclListDto>>(createDto);
                if (response != null && response.Success && response.Data != null)
                {
                    TempData["success"] = "Exclusion has been added to the list succesfully";
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }

            return View(createDto);
        }


        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id)
        {
            if (id <= 0)
            {
                TempData["error"] = "Invalid Id";
                return RedirectToAction(nameof(Index));
            }

            try
            {
                var response = await _pullbExclListService.GetAsync<ApiResponse<PullbackExclListDto>>(id);
                if (response != null && response.Success && response.Data != null)
                {
                    return View(_mapper.Map<PullbackExclListUpdateDto>(response.Data));
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(PullbackExclListUpdateDto updateDto)
        {

            try
            {
                // Convert bool to "Y" / "N"
                var exclValue = updateDto.EXCL ? "Y" : "N";

                // Replace the DTO value with the converted one
                updateDto.EXCL = exclValue == "Y";

                var response = await _pullbExclListService.UpdateAsync<ApiResponse<object>>(updateDto);
                if (response != null && response.Success && response.Data != null)
                {
                    TempData["success"] = "Exclusion has been updated succesfully";
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }


        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            if(id<= 0)
            {
                TempData["error"] = "Invalid Id";
                return RedirectToAction(nameof(Index));
            }

            try
            {

                var response = await _pullbExclListService.GetAsync<ApiResponse<PullbackExclListDto>>(id);
                if (response != null && response.Success && response.Data != null)
                {
                    return View(response.Data);
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(PullbackExclListDto pullbackExclListDto)
        {

            try
            {

                var response = await _pullbExclListService.DeleteAsync<ApiResponse<object>>(pullbackExclListDto.ID);
                if (response != null && response.Success && response.Data != null)
                {
                    TempData["success"] = "Exclusion has been deleted succesfully";
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }

            return RedirectToAction(nameof(Index));
        }


        [Authorize(Roles = "Admin")]
        public IActionResult UploadCsv()
        {
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadCsv(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                TempData["error"] = "Please choose a CSV file to upload.";
                return View();
            }

            try
            {
                var response = await _pullbExclListService.UploadCsvAsync<ApiResponse<PullbackExclListCsvUploadResultDto>>(file);

                if (response != null && response.Success && response.Data != null)
                {
                    TempData["success"] = response.Message;
                    return View("UploadCsvResult", response.Data);
                }

                TempData["error"] = response?.Message ?? "An error occured while uploading the CSV file.";
            }
            catch (Exception ex)
            {
                TempData["error"] = $"An error ocured:{ex.Message}";
            }

            return View();
        }

    }
}
