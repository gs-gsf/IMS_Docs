using IMS_DTO.Inventory.Pullback;
using IMS_WEB.Services;
using IMS_WEB.Services.IServices;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();

//here we will be able to inject the AddHttpContextAccessor and access the context 
//+ add sessions with 60 minutes time out
builder.Services.AddHttpContextAccessor();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddAutoMapper(options =>
{
    options.CreateMap<PullbackExclListDto, PullbackExclListCreateDto>().ReverseMap();
    options.CreateMap<PullbackExclListUpdateDto, PullbackExclListDto>().ReverseMap();
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.Cookie.HttpOnly = true;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(60);
        options.SlidingExpiration = true;
        options.LoginPath = "/auth/login";
        options.AccessDeniedPath = "/auth/accessdenied";
    });

builder.Services.AddHttpClient("PullExAPI", client =>
{
    var PullbExclListAPIUrl = builder.Configuration.GetValue<string>("ServiceUrls:PullbExclListAPI");
    client.BaseAddress = new Uri(PullbExclListAPIUrl);
    client.DefaultRequestHeaders.Add("Accept", "application/json");
});

builder.Services.AddScoped<ITokenProvider, TokenProvider>();
builder.Services.AddScoped<IPullbExclListService, PullbExclListService>();
builder.Services.AddScoped<IAuthService, AuthService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
