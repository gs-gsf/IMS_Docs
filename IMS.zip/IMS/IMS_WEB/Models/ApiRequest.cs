﻿using Microsoft.AspNetCore.Http;
using static IMS_WEB.SD;

namespace IMS_WEB.Models
{
    public class ApiRequest
    {
        public ApiType ApiType { get; set; } = ApiType.GET;
        public string? Url { get; set; } //this will be the Url where we want to call the API
        public object? Data { get; set; }
        public string? Token { get; set; }

        //when populated, the request will be sent as multipart/form-data instead of JSON
        public IFormFile? File { get; set; }
        public string FileFieldName { get; set; } = "file";

    }
}
