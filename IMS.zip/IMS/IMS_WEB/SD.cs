﻿namespace IMS_WEB
{
    public static class SD
    {
        public enum ApiType
        {
            GET,
            POST,
            PUT,
            DELETE
        }

        public const string SessionAccessToken = "JWTToken";
        public const string SessionRefreshToken = "RefreshToken";
        public const string CurrentAPIVersion = "v1";

    }
}
