﻿using IMS_DTO.Inventory.Pullback;
using IMS_WEB.Models;
using IMS_WEB.Services.IServices;
using Microsoft.AspNetCore.Http;
using System.Data;

namespace IMS_WEB.Services
{
    public class PullbExclListService : BaseService, IPullbExclListService
    {
        private readonly string _pullbExclListUrl;
        //private const string APIEndpoint = "/api/PullbackExclList";
        private const string APIEndpoint = $"/api/{SD.CurrentAPIVersion}/PullbackExclList";
        public PullbExclListService(IHttpClientFactory httpClient,IConfiguration configuration, ITokenProvider tokenProvider) 
            : base(httpClient, tokenProvider)
        {         
        }

        public Task<T?> GetAllAsync<T>(string? filterBy = null,
                string? filterQuery = null,
                string? sortBy = null,
                string? sortOrder = null,
                int page = 1,
                int pageSize = 10)
        {
            var queryString =
                $"?filterBy={filterBy}" +
                $"&filterQuery={filterQuery}" +
                $"&sortBy={sortBy}" +
                $"&sortOrder={sortOrder}" +
                $"&page={page}" +
                $"&pageSize={pageSize}";

            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.GET,
                Url = $"{APIEndpoint}{queryString}"
            });
        }

        public Task<T?> GetAsync<T>(int id)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.GET,
                Url = $"{APIEndpoint}/{id}"
            });
        }

        public Task<T?> CreateAsync<T>(PullbackExclListCreateDto dto)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.POST,
                Data = dto,
                Url = APIEndpoint
            });
        }

        public Task<T?> DeleteAsync<T>(int id)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.DELETE,
                Url = $"{APIEndpoint}/{id}"
            });
        }


        public Task<T?> UpdateAsync<T>(PullbackExclListUpdateDto dto)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.PUT,
                Data = dto,
                Url = $"{APIEndpoint}/{dto.ID}"
            });
        }

        public Task<T?> UploadCsvAsync<T>(IFormFile file)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.POST,
                File = file,
                Url = $"{APIEndpoint}/upload-csv"
            });
        }
    }
}
