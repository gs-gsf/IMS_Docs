﻿using IMS_DTO;
using IMS_WEB.Models;
using IMS_WEB.Services.IServices;
using System.Net.Http.Headers;
using System.Text.Json;

namespace IMS_WEB.Services
{
    public class BaseService : IBaseService
    {
        public IHttpClientFactory _httpClient {  get; set; }
        private readonly ITokenProvider _tokenProvider;
        private static readonly JsonSerializerOptions JsonOptions = new()
        {
            PropertyNameCaseInsensitive = true
        };
        public ApiResponse<object> ResponseModel { get; set; }

        public BaseService(IHttpClientFactory httpClient, ITokenProvider tokenProvider)
        {
            this.ResponseModel = new();
            _httpClient = httpClient;
            _tokenProvider = tokenProvider;
        }

        public async Task<T?> SendAsync<T>(ApiRequest apiRequest,bool withBearer = true)
        {
            try
            {
                var client = _httpClient.CreateClient("PullExAPI");

                //this will be the message we will be sending from WEB to API including the Uri
                var message = new HttpRequestMessage
                {
                    RequestUri = new Uri(apiRequest.Url,uriKind:UriKind.Relative),
                    Method = GetHttpMethod(apiRequest.ApiType)
                };

                //retrieve the token if that is populated in session
                //var token = _httpContextAccessor.HttpContext?.Session?.GetString(SD.SessionToken);
                var token = _tokenProvider.GetAccessToken();

                //we can check if bearer is tru only then we append the token
                if (withBearer && !string.IsNullOrEmpty(token))
                {
                    message.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }

                //if we have a file, we send it as multipart/form-data instead of JSON
                if (apiRequest.File != null)
                {
                    var multipartContent = new MultipartFormDataContent();
                    var fileStreamContent = new StreamContent(apiRequest.File.OpenReadStream());
                    fileStreamContent.Headers.ContentType = new MediaTypeHeaderValue(
                        string.IsNullOrEmpty(apiRequest.File.ContentType) ? "application/octet-stream" : apiRequest.File.ContentType);

                    multipartContent.Add(fileStreamContent, apiRequest.FileFieldName, apiRequest.File.FileName);
                    message.Content = multipartContent;
                }
                //if we have the data we are adding that inside HTTP request  
                else if (apiRequest.Data != null)
                {
                    message.Content = JsonContent.Create(apiRequest.Data, options: JsonOptions);
                }

                //when we send the message to the API we will get a response
                var apiResponse = await client.SendAsync(message);

                //once we receive the response we need to use Json deserializer
                return await apiResponse.Content.ReadFromJsonAsync<T>(JsonOptions);
            }
            catch (Exception ex) 
            { 
                Console.WriteLine($"Unexpected error: {ex.ToString()}");
                return default;
            }
        }

        //it will return apiType dynamically
        private static HttpMethod GetHttpMethod(SD.ApiType apiType)
        {
            return apiType switch
            {
                SD.ApiType.POST => HttpMethod.Post,
                SD.ApiType.PUT => HttpMethod.Put,
                SD.ApiType.DELETE => HttpMethod.Delete,
                _ => HttpMethod.Get //this will be the default
            };
        }

    }
}
