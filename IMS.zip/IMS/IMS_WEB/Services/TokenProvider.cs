﻿using IMS_WEB.Services.IServices;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace IMS_WEB.Services
{
    public class TokenProvider : ITokenProvider
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        public TokenProvider(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public void ClearToken()
        {
            _httpContextAccessor.HttpContext?.Session.Remove(SD.SessionAccessToken);
            _httpContextAccessor.HttpContext?.Session.Remove(SD.SessionRefreshToken);
        }

        public ClaimsPrincipal CreatePrincipalFromJwtToken(string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                return null;
            }

            try
            {
                //here we extract the token. From jwt we can extract the Claim what has been added to API project AuthService.cs where we have GenerateJwtToken()
                var handeler = new JwtSecurityTokenHandler();
                var jwt = handeler.ReadJwtToken(token);

                //here we create a claims identity
                var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme);

                //when we are adding claims we are adding that on the web project. And because web project is also .Net has a built in mechanism of adding security.
                //That way automatically sign in or sign out the user using its built in mechanism for handling authentication.
                //we are checking if there is a claim only after that we are adding it 

                var emailClaim = jwt.Claims.FirstOrDefault(u => u.Type == "email");
                if (emailClaim != null)
                {
                    identity.AddClaim(new Claim(ClaimTypes.Name, emailClaim.Value));
                }

                var roleClaim = jwt.Claims.FirstOrDefault(u => u.Type == "role");
                if (roleClaim != null)
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, roleClaim.Value));
                }


                /*
                //if we need to add more claims we can add like below example
                var nameClaim = jwt.Claims.FirstOrDefault(u => u.Type == "name");
                if (nameClaim != null)
                {
                    identity.AddClaim(new Claim("FullName", nameClaim.Value));
                }
                */

                return new ClaimsPrincipal(identity);
            }
            catch (Exception ex) 
            {
                return null;
            }
        }

        public string? GetAccessToken()
        {
            return _httpContextAccessor.HttpContext?.Session.GetString(SD.SessionAccessToken);
        }

        public string? GetRefreshToken()
        {
            return _httpContextAccessor.HttpContext?.Session.GetString(SD.SessionRefreshToken);
        }

        public void SetToken(string accessToken, string refreshToken)
        {
            _httpContextAccessor.HttpContext?.Session.SetString(SD.SessionAccessToken, accessToken);
            _httpContextAccessor.HttpContext?.Session.SetString(SD.SessionRefreshToken, refreshToken);

        }




    }
}
