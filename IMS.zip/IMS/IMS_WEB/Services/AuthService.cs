﻿using IMS_DTO.Users;
using IMS_WEB.Models;
using IMS_WEB.Services.IServices;

namespace IMS_WEB.Services
{
    public class AuthService : BaseService, IAuthService
    {
        private const string APIEndpoint = "/api/auth";
        //private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthService(IHttpClientFactory httpClient, IConfiguration configuration, ITokenProvider tokenProvider) 
           : base(httpClient, tokenProvider)
        {
            //_httpContextAccessor = httpContextAccessor;
        }

        public Task<T?> LoginAsync<T>(LoginRequestDTO loginRequestDTO)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.POST,
                Data = loginRequestDTO,
                Url = APIEndpoint + "/login"
            },withBearer:false);
        }

        public Task<T?> RegisterAsync<T>(RegisterationRequestDTO registerationRequestDTO)
        {
            return SendAsync<T>(new ApiRequest
            {
                ApiType = SD.ApiType.POST,
                Data = registerationRequestDTO,
                Url = APIEndpoint + "/register"
            }, withBearer: false);
        }
    }
}
