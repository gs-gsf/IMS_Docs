﻿using IMS_DTO.Inventory.Pullback;
using Microsoft.AspNetCore.Http;

namespace IMS_WEB.Services.IServices
{
    public interface IPullbExclListService
    {
        Task<T?> GetAllAsync<T>(string? filterBy = null,
            string? filterQuery = null,
            string? sortBy = null,
            string? sortOrder = null,
            int page = 1,
            int pageSize = 10);
        Task<T?> GetAsync<T>(int id);
        Task<T?> CreateAsync<T>(PullbackExclListCreateDto dto);
        Task<T?> UpdateAsync<T>(PullbackExclListUpdateDto dto);
        Task<T?> DeleteAsync<T>(int id);
        Task<T?> UploadCsvAsync<T>(IFormFile file);
    }
}
