﻿using IMS_DTO;
using IMS_WEB.Models;

namespace IMS_WEB.Services.IServices
{
    public interface IBaseService
    {
        //here we will receive the response
        ApiResponse<object> ResponseModel { get; set; }

        //here we have a method to send or call our API end points
        Task<T> SendAsync<T>(ApiRequest apiRequest, bool withBearer = true);
    }
}
