﻿using System.Security.Claims;

namespace IMS_WEB.Services.IServices
{
    public interface ITokenProvider
    {
        void SetToken(string accessToken, string refreshToken);
        string? GetAccessToken();
        string? GetRefreshToken();
        void ClearToken();
        ClaimsPrincipal CreatePrincipalFromJwtToken(string token);
    }
}
