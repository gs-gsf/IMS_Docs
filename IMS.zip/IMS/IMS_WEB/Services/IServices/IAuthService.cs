﻿using IMS_DTO.Users;

namespace IMS_WEB.Services.IServices
{
    public interface IAuthService
    {
        Task<T?> LoginAsync<T>(LoginRequestDTO loginRequestDTO);
        Task<T?> RegisterAsync<T>(RegisterationRequestDTO registerationRequestDTO);
    }
}
